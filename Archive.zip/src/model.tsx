import React, { useState } from 'react';
import { Divider, Input, Select } from "antd";
import DataSelector from "./data_selector";
import { PageHeader } from '@ant-design/pro-components';

function Model() {
  const [trainingSet, setTrainingSet] = useState("");
  const [testSet, setTestSet] = useState("");
  const [validationSet, setValidationSet] = useState("");
  const [modelName, setModelName] = useState("");
  const [architecture, setArchitecture] = useState("Autoformer");
  const [seqLen, setSeqLen] = useState("");
  const [labelLen, setLabelLen] = useState("");
  const [eLayers, setELayers] = useState("");
  const [dLayers, setDLayers] = useState("");
  const [factor, setFactor] = useState("");
  const [encIn, setEncIn] = useState("");
  const [decIn, setDecIn] = useState("");
  const [cOut, setCOut] = useState("");
  const [itr, setItr] = useState("");

  const architectureOptions = ["Autoformer", "Transformer", "TimesNet"];

  return (
    <>
      <PageHeader title={"模型"}>
        你可以在这里对模型进行训练(根据数据集)，选择数据集和需要的架构，就可以训练出模型。
      </PageHeader>
      <Divider />
      选择训练集
      <DataSelector />
      选择测试集
      <DataSelector />
      选择验证集
      <DataSelector />
      模型的保存名字:
      <Input value={modelName} onChange={(e) => setModelName(e.target.value)} />
      选择架构:
      <Select value={architecture} onChange={(value) => setArchitecture(value)} options={architectureOptions.map((e, idx) => {
        return {
          value: e,
          label: e
        }
      })}>
      </Select>
      seq_len:
      <Input value={seqLen} onChange={(e) => setSeqLen(e.target.value)} />
      label_len:
      <Input value={labelLen} onChange={(e) => setLabelLen(e.target.value)} />
      e_layers:
      <Input value={eLayers} onChange={(e) => setELayers(e.target.value)} />
      d_layers:
      <Input value={dLayers} onChange={(e) => setDLayers(e.target.value)} />
      factor:
      <Input value={factor} onChange={(e) => setFactor(e.target.value)} />
      enc_in:
      <Input value={encIn} onChange={(e) => setEncIn(e.target.value)} />
      dec_in:
      <Input value={decIn} onChange={(e) => setDecIn(e.target.value)} />
      c_out:
      <Input value={cOut} onChange={(e) => setCOut(e.target.value)} />
      itr:
      <Input value={itr} onChange={(e) => setItr(e.target.value)} />
    </>
  );
}

export default Model;
