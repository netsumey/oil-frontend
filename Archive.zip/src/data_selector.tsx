import {useEffect, useState} from "react";
import {Select} from "antd";

function DataSelector() {
  const [fileName, setFileName] = useState('无');
  const [fileNames, setFileNames] = useState([]);

  useEffect(() => {
    fetch('http://localhost:8888/data/get_names', {
      method: 'POST'
    }).then((res) => res.json())
      .then((res) => setFileNames(JSON.parse(res.names)))
  }, []);

  return (
    <>
      <Select
        defaultValue={fileName}
        onChange={(value) => setFileName(value)}
        options={fileNames.map((e) => ({ value: e, label: e }))}
      />
    </>
  )
}

export default DataSelector;